import React from "react";

export default function Registration(){
    return(
        <div>Registration</div>
    )
}