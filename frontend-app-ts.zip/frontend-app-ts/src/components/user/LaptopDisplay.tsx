import React from "react";
import '../asset/css/Container.css';
import Listproduct from "./Listproduct";

export default function LaptopDisplay(){
    return(
        <>
  <div id="promotion">
    <p>Khuyến mãi hot</p>
    <div id="list-product">
      <Listproduct/>
    </div>
  </div>
  <div id="discout-weekend">
    <div className="image">
      <img src="images/apple-discount.png" alt="" />
      <img src="images/phone-discount.png" alt="" />
      <img src="images/laptop-discount.png" alt="" />
      <img src="images/houseware-discount.png" alt="" />
    </div>
    <div className="buy-now">MUA NGAY</div>
  </div>
  <img src="images/slode-laptop.webp" alt="" id="banner" />
  <div id="ads">
    <img src="images/card.png" alt="" />
    <img src="images/ads.png" alt="" />
    <img src="images/ads2.png" alt="" />
  </div>
</>

    )
}