import React from "react";
import '../asset/css/Header.css';
import '../asset/font/themify-icons-font/themify-icons/themify-icons.css';
import { Link } from "react-router-dom";
export default function Header(){
    return(
        <div id="nav">
  <a href="/index.html">
    <img src="/img/logo.png" alt="" />
  </a>
  <input type="text" placeholder="Nhập tên phụ kiện cần tìm" />
  <button className="search-btn">
    <i className="icon ti-search" />
  </button>
  <ul id="convinient">
    <li>
      <a href="">
        <i className="icon1 ti-save" />
        Thông tin hay
      </a>
      <ul className="sub-conv">
        <li>
          <a href="">Tin mới</a>{" "}
        </li>
        <li>
          <a href="">Khuyến mãi</a>{" "}
        </li>
        <li>
          <a href="">Điện máy-Gia dụng</a>{" "}
        </li>
        <li>
          <a href="">Thủ thuật</a>
        </li>
        <li>
          <a href="">For Gamers</a>
        </li>
        <li>
          <a href="">Video hot</a>
        </li>
        <li>
          <a href="">Đánh giá-tư vấn</a>
        </li>
        <li>
          <a href="">App &amp; Game</a>
        </li>
        <li>
          <a href="">Sự Kiện</a>
        </li>
      </ul>
    </li>
    <li>
      <a href="">
        <i className="icon1 ti-bookmark-alt" />
        Thanh toán &amp; tiện ích
      </a>
    </li>
    <li>
      <Link to="/abc">
        <i className="icon1 ti-user" />
        Tài khoản của tôi
      </Link>
    </li>
    <li>
      <a href="cart.html">
        <i className="icon1 ti-shopping-cart" />
        Giỏ hàng
      </a>
    </li>
  </ul>
</div>

    )
}