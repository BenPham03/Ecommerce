import React from "react";
import '../asset/css/Menu.css'
import { Link } from "react-router-dom";

export default function Menu(){
    return(
        <div id="menu">
  <ul className="nav">
    <li>
      <i className="icon ti-mobile " />
      <Link to="/latoppage">Laptop</Link>
    </li>
    <li>
      <i className="icon ti-tablet" />
      <a href="">Máy tính bảng</a>
    </li>
    <li>
      <i className="icon ti-apple" />
      <a href="">Apple</a>
    </li>
    <li>
      <i className="icon ti-blackboard" />
      <a href="">Pc-Linh kiện</a>
    </li>
    <li>
      <i className="icon ti-headphone" />
      <a href="">Phụ kiện</a>
    </li>
    <li>
      <i className="icon ti-reload" />
      <a href="">Máy cũ giá rẻ</a>
    </li>
    {/* <li><i class="icon ti-home"></i><a href="">Hàng gia dụng</a></li> */}
    {/* <li><i class="icon ti-save-alt"></i><a href="">Sim thẻ</a></li> */}
    <li>
      <i className="icon ti-settings" />
      <a href="">Khuyến mãi</a>
      <ul className="subnav">
        <li>
          <a href="">Thông tin trao thưởng</a>
        </li>
        <li>
          <a href="">Tất cả khuyến mãi</a>
        </li>
      </ul>
    </li>
  </ul>
</div>

    )
}