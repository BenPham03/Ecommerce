export default function SlideLaptop() {
    // var imgFeature = document.querySelector(".img-feature");
    // var listImg = document.querySelectorAll("#slide-show .list-img div ");
    // // var listdiv = document.querySelectorAll('#slide-show .list-img div')
    // var preBtn = document.querySelector("#slide-show .icon1");
    // var nextBtn = document.querySelector("#slide-show .icon2");
    // // var p1 = document.querySelector
    // var currentIndex = 0;
    // function updateImageByIndex(index:any) {
    //     //remove active
    //     document.querySelectorAll("#slide-show .list-img div").forEach((item) => {
    //     item.classList.remove("active");
    //     });
    //     currentIndex = index;
    //     imgFeature.src = listImg[index].getAttribute("src");
    //     listImg[index].classList.add("active");
    // }
    // listImg.forEach((imgElement, index) => {
    //     imgElement.addEventListener("click", (e) => {
    //     updateImageByIndex(index);
    //     });
    // });
    // preBtn.addEventListener("click", (e) => {
    //     if (currentIndex == 0) {
    //     currentIndex = listImg.length - 1;
    //     } else {
    //     currentIndex--;
    //     }
    //     updateImageByIndex(currentIndex);
    // });
    // nextBtn.addEventListener("click", (e) => {
    //     if (currentIndex == listImg.length - 1) {
    //     currentIndex = 0;
    //     } else {
    //     currentIndex++;
    //     }
    //     updateImageByIndex(currentIndex);
    // });
  return (
    <>
      <div id="slide-show">
        <div className="main">
          <img className="img-feature" src="/img/slidelap1.webp" />
          <i className="icon1 ti-angle-left" />
          <i className="icon2 ti-angle-right" />
        </div>
        <div className="list-img">
          <div className="active">
            <img src="images/slidelap1.webp" alt="" />
          </div>
          {/* <div src="img/slidelap2.webp" />
          <div src="img/slidelap3.webp" />
          <div src="img/slidelap4.webp" />
          <div src="img/slidelap5.webp" />
          <div src="img/slidelap6.webp" />
          <div src="img/slidelap7.webp" />
          <div src="img/slidelap8.webp" />
          <div src="img/slidelap9.webp" />
          <div src="img/slidelap10.webp" /> */}
        </div>
      </div>
    </>
  );
}
