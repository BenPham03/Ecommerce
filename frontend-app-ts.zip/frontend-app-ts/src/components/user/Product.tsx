export default function Product(props: any) {
    return(
        <>
        <div className="product1">
        <img className="image" src="images/caymt.webp" alt="" />
        <p className="txt1">Trả góp 0%</p>
        <p className="txt2">Giảm 6.000.000đ</p>
        <h1>
          {props.data.name}
        </h1>
        <div className="price">
          <p />
          <div className="num">{props.data.price}</div>{" "}
          <div className="unit">
            <u>đ</u>
          </div>
          <p />
        </div>
        </div>
        </>
    )
}