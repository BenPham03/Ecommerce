import React from "react";

export default function AdminOrders(){
    return(
        <div>AdminOrders</div>
    )
}