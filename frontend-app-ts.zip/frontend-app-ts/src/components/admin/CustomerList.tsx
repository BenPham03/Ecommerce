import React from "react";

export default function CustomerList(){
    return(
        <div>CustomerList</div>
    )
}