import React from "react";

export default function Laptop(){
    return(
        <div>Laptop</div>
    )
}