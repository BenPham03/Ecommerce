import React from "react";
import {BrowserRouter as Router, Routes, Route} from 'react-router-dom'
import Homepage from "../Page/Homepage";
import LaptopPage from "../Page/LaptopPage";

export default function RouterPage(){
    return(
        // <Router>
            <Routes>
                <Route path='/' element= {<Homepage />}/> 
                <Route path='/latoppage' element = {<LaptopPage/>}/>
            </Routes>
        // </Router>
    )
}