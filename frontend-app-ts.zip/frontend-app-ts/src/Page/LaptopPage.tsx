import Header from "../components/user/Header";
import Menu from "../components/user/Menu";
import SlideLaptop from "../components/user/SlideLaptop";

export default function LaptopPage(){
    return(
        <>
            <Header />
            <Menu />
            <div id="container">
                <SlideLaptop/>
            </div>
        </>
    )

}