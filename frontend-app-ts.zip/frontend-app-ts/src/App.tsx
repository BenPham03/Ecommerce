import React from 'react';
import logo from './logo.svg';
import './App.css';
import { Container } from 'react-bootstrap';
import { BrowserRouter } from 'react-router-dom';
import Header from './components/user/Header';
import Menu from './components/user/Menu';
import Slider from './components/user/Slider';
import Category from './components/user/Category';
import LaptopDisplay from './components/user/LaptopDisplay';
import Footer from './components/user/Footer';
import Homepage from './Page/Homepage';
import RouterPage from './components/RouetrPage';

function App() {
  return (
    <Container>
      {/* <Homepage/> */}
      <BrowserRouter>
        <RouterPage/>
      </BrowserRouter>
    </Container>
  );
}

export default App;
